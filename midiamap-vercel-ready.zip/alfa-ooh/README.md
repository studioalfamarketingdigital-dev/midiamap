# MídiaMap

Marketplace de mídia e publicidade da S.Alfa MKT.

## Domínio
https://midiamap.studioalfamkt.online

## Stack
Next.js + TypeScript + CSS. Preparado para deploy na Vercel.

## GitHub / Vercel
1. Crie um repositório chamado `midiamap` no GitHub.
2. Envie os arquivos deste projeto para o repositório.
3. Importe o repositório na Vercel.
4. Em Vercel > Settings > Domains, adicione `midiamap.studioalfamkt.online`.
5. No DNS de `studioalfamkt.online`, crie o registro indicado pela Vercel para o subdomínio.
6. Depois do deploy, valide `/robots.txt` e `/sitemap.xml`.
7. Cadastre `https://midiamap.studioalfamkt.online/sitemap.xml` no Google Search Console.

## Próxima fase
- inventário real via banco/API;
- mapa interativo e geolocalização;
- filtros por cidade, formato, período e preço;
- cadastro de exibidores;
- disponibilidade/reserva;
- checkout e pagamento;
- painel do anunciante;
- painel do proprietário de mídia;
- integração com parceiros de OOH, DOOH, TV e rádio.
